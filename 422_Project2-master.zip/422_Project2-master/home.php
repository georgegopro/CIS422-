<html>
<head>

<title>Dolla Tree</title>
<link href="dolla.css" rel="stylesheet" type="text/css" />

</head>

<body>


<div id="header">
	Free Dolla Games
</div>

<div id="intro">
	Welcome to the dolla tree website.<br>
	You can play as a guest or you can create an account.<br>
	If you create an account we'll keep track of your high scores<br> 
	so you can play against yourself or your friends.<br><br>
</div>


<div id="pageStuff">
	<a href = "register.php" class="button">Sign up</a><br><br><br>
	<a href = "signIn.php" class="button">Log in</a><br><br><br>
	<a href = "dolla.php" class="button">Play as guest</a><br><br><br>
</div>




</body>
</html>
