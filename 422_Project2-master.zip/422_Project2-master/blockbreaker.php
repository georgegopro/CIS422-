<html>
<head>

<title>Dolla Tree BlockBreaker</title>
<link href="dolla.css" rel="stylesheet" type="text/css" />
<script language = "javascript" src = "brick/game.js"></script>
</head>

<body>


<div id="header">
	Free Dolla Games
</div>

<div id="intro">
	Welcome to blockbreaker. This is how you play...<br><br>
	<iframe src="brick/game.html" height="515" width="515"></iframe>
</div>

<div id="pageStuff">

</div>
<div style="height: 150px;">

</div>
<table border="1" align="center">
	<tr>
		<td id ="" height = "20px" width = "150px" name="">Your High Score</td>
		<td id ="" height = "20px" width = "150px" name="">Overall High Score</td>
	</tr>

	<tr>
		<td id ="" height = "20px" width = "150px" name=""></td>
		<td id ="" height = "20px" width = "150px" name=""></td>
	</tr>
</table>
<br><br>
<?php
	include_once('footer.php');
?>

</body>
</html>
