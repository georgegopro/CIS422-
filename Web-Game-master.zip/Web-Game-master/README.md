# Web-Game
A small game done using Javascript

It is Web course small project which requires design a small javascript program. 
Here this one is a small game that is based on tutorial.

